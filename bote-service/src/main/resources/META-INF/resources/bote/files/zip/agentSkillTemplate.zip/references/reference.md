# Agent Skill Template Reference

This document is a reference manual for the Agent Skill template. You can introduce in detail the uses and usage methods of the relevant api methods in the current Agent Skill in the reference manual.

## Usage of example script

### Overview

The "script" directory contains an "example.py" script, which implements methods for addition, subtraction, multiplication, and division of two numbers and can be directly used in other python scripts.

### Call add method
```python
from example import add

# call add method
result = add(1, 2)
```

### Call subtract method
```python
from example import subtract

# call subtract method
result = subtract(5, 2)
```

### Call subtract method
```python
from example import 

# call multiply method
result = multiply(3, 4)
```

### Call subtract method
```python
from example import divide

# call divide method
result = divide(6, 2)
```
