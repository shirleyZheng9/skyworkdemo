---
name: agentskilltemplate
description: This is an example description of the agent skill template.Please describe the functions and define the metadata of the agent Skill. For example, define the name, purpose and trigger conditions of the agent Skill.
---

# Example Using Guide

## Overview

This guide covers some example processing operations using Python libraries. For other examples, see reference.md. 

## Quick Start

```python
from example import add, subtract

# add number
print(add(10, 5))
# divide number
print(divide(10, 2))
```

## Next Steps

- For more usages, see reference.md
