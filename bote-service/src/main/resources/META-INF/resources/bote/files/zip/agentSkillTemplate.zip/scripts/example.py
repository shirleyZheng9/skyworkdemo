#!/usr/bin/env python3
"""
Agent Skill Script Example: Number Calculator Script.
"""

import sys

def add(a, b):
    """返回 a 与 b 的和"""
    return a + b

def subtract(a, b):
    """返回 a 减去 b 的结果"""
    return a - b

def multiply(a, b):
    """返回 a 与 b 的乘积"""
    return a * b

def divide(a, b):
    """返回 a 除以 b 的结果，若 b 为 0 则抛出异常"""
    if b == 0:
        raise ValueError("除数不能为零")
    return a / b

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python calculator.py num01 num02")
        sys.exit(1)
    num01 = float(sys.argv[1])
    num02 = float(sys.argv[2])
    print(add(num01, num02))
