# 目录结构要求说明
* `SKILL.md`：agentSkill说明书与元数据，定义agentSkill名称、用途和触发条件【必选】
* `scripts/`：存放可执行代码脚本，用于处理确定性计算任务【可选】
* `references/`：存放参考文档，如API手册、行业规范等【可选】
* `assets/`：存放静态资源，如模板文件、音视频素材等【可选】